WONDERDOT - RPG Village Tileset

==============================================================

Contents -----------------------------------------------------

Village_Tileset.png		-Tileset
AltRoofs_Tileset.png		-Palette swaps of roof tiles


Readme.txt			-This file
License.txt			-License for these assets

Guide/...
Village Tileset Guide.html	-Documentation on use and tips
images/...			-Guide images

Tiled/...
Example.tmx			-A large example scene, plus examples used in guide
				 (open in Tiled Map Editor)
Village_Tileset.tsx		-Tileset data for the .tmx file


==============================================================

Thank you for your support!

-Pita

twitter.com/pita_akm
pita.madgwick@gmail.com