

Z,Q,S,D => d�placer la cam�ra
Fleches => Selection de sprites
O => ouvrir une map
P => enregistrer sous la map
1234 => changer le(s) layer(s) affich�(s)
tab => changer le layer de dessin
Shift => rotation verticale
Control => rotation horizontale
Espace => Editeur collisions