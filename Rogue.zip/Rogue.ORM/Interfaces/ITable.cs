﻿namespace Rogue.ORM.Interfaces
{
    public interface ITable
    {
        
    }
}
