﻿using System;

namespace Rogue.ORM.Attributes
{
    public class PrimaryAttribute : Attribute
    {
        public PrimaryAttribute()
        { }
    }
}
