﻿using System;

namespace Rogue.ORM.Attributes
{
    public class IgnoreAttribute : Attribute
    {
        public IgnoreAttribute()
        {

        }
    }
}
