﻿using System;

namespace Rogue.ORM.Attributes
{
    public class UpdateAttribute : Attribute
    {
        public UpdateAttribute()
        {

        }
    }
}
